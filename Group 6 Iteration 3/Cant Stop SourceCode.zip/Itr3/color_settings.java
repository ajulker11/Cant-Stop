

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class color_settings extends JFrame implements ActionListener, MouseListener{
	JLabel header= new JLabel();
	JLabel med_text= new JLabel();
	JLabel bot_text= new JLabel();
	JLabel label= new JLabel(); 
	JLabel label1= new JLabel();
	JLabel label2= new JLabel();
	JLabel label3= new JLabel();
	JButton button = new JButton();
	JButton button1 = new JButton();
	JButton button2 = new JButton();
	JButton button3 = new JButton(); 
	JButton button4= new JButton();
	public color_settings(){
		this.setSize(600,700);
		this.setTitle("Color Settings");
		this.getContentPane().setBackground(new Color(0x16A4DD));
		this.setLayout(new BorderLayout());
		this.setVisible(true); 
		header.setText(" Can't");
		header.setFont(new Font("Comic Sans MS",Font.BOLD,46)); 
		header.setForeground(Color.white); 
		
		Border border= new LineBorder(Color.BLACK,6);
		
		//button1.setAlignmentY(Component.TOP_ALIGNMENT);
		//button4.setPreferredSize(new Dimension(100,50));
	
		
		
		JPanel topPanel= new JPanel();
		topPanel.setLayout(new BoxLayout(topPanel,BoxLayout.Y_AXIS));
		topPanel.add(Box.createVerticalStrut(30));
		topPanel.setBackground(new Color(0x16A4DD));
		header.setAlignmentX(Component.CENTER_ALIGNMENT);
		topPanel.add(header); 
		med_text.setText("Stop");
		med_text.setFont(new Font("Comic Sans MS",Font.BOLD,46)); 
		med_text.setAlignmentX(Component.CENTER_ALIGNMENT);
		med_text.setForeground(Color.white); 
		
		bot_text.setText("Color Modes");
		bot_text.setFont(new Font("Comic Sans MS",Font.BOLD,46)); 
		bot_text.setAlignmentX(Component.CENTER_ALIGNMENT);
		bot_text.setForeground(Color.BLACK);
		
		topPanel.add(med_text);
		topPanel.add(bot_text);
		topPanel.setBorder(BorderFactory.createEmptyBorder(20,20,40,20));
		
		
		//button.setBounds(195,170,00,50);	
		
		button.setText("Default"); 
		button.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button.setBackground(Color.white); 
		button.setBorder(border);
		button.setAlignmentY(Component.TOP_ALIGNMENT);
		button.setPreferredSize(new Dimension(200,50)); 
		button.addMouseListener(this); 
		
		button1.setText("Batman"); 
		button1.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button1.setBackground(Color.white); 
		button1.setBorder(border);
		//button1.setAlignmentY(Component.TOP_ALIGNMENT);
		button1.setPreferredSize(new Dimension(200,50)); 
		button1.addMouseListener(this);
		
		button2.setText("wolverine"); 
		button2.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button2.setBackground(Color.white); 
		button2.setBorder(border);
		//button1.setAlignmentY(Component.TOP_ALIGNMENT);
		button2.setPreferredSize(new Dimension(200,50)); 
		button2.addMouseListener(this);
		
		button3.setText("Galactus"); 
		button3.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button3.setBackground(Color.white); 
		button3.setBorder(border);
		//button1.setAlignmentY(Component.TOP_ALIGNMENT);
		button3.setPreferredSize(new Dimension(200,50));
		button3.addMouseListener(this); 
		
		button4.setText("Back"); 
		button4.setBounds(155, 50, 100, 50);
		button4.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button4.setBackground(Color.white); 
		button4.setBorder(border);
		button4.setPreferredSize(new Dimension(100,50));
		button4.addMouseListener(this); 
		
		
		ImageIcon icon=new ImageIcon(this.getClass().getResource("mode1.png")); 
		label.setIcon(icon);
		
		ImageIcon icon1=new ImageIcon(this.getClass().getResource("mode2.png")); 
		label1.setIcon(icon1);
		
		ImageIcon icon2=new ImageIcon(this.getClass().getResource("mode3.png")); 
		label2.setIcon(icon2);
		
		ImageIcon icon3=new ImageIcon(this.getClass().getResource("mode4.png")); 
		label3.setIcon(icon3);
		
	
		JPanel buttonPanel= new JPanel(new FlowLayout(FlowLayout.CENTER));
		JPanel buttonPanel1= new JPanel();
		buttonPanel.setBackground(new Color(0x16A4DD)); 
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
		buttonPanel.add(button);
		buttonPanel.add(button1);  
		
		JPanel panel1= new JPanel();
		panel1.setBackground(new Color(0x16A4DD));
		panel1.setPreferredSize(new Dimension(50,50)); 
		panel1.add(button); 
		panel1.add(label1);
		
		
		JPanel panel2= new JPanel();
		panel2.setPreferredSize(new Dimension(50,50)); 
		panel2.setBackground(new Color(0x16A4DD));
		panel2.add(button1); 
		panel2.add(label);
		
		JPanel panel3= new JPanel();
		panel3.setPreferredSize(new Dimension(50,50)); 
		panel3.setBackground(new Color(0x16A4DD));
		panel3.add(button2); 
		panel3.add(label2); 
		
		JPanel panel4= new JPanel();
		//panel4.setLayout(new BorderLayout());
		panel4.setPreferredSize(new Dimension(50,50)); 
		panel4.setBackground(new Color(0x16A4DD));
		panel4.add(button3); 
		panel4.add(label3); 
		//panel4.add(button4, BorderLayout.WEST);  
		
		JPanel panel5= new JPanel(new FlowLayout(FlowLayout.LEFT));
		//panel4.setLayout(new BorderLayout());
		panel5.setPreferredSize(new Dimension(50,50)); 
		panel5.setBackground(new Color(0x16A4DD));
		panel5.add(button4); 
		
		
		
		buttonPanel.add(panel1); 
		buttonPanel.add(panel2); 
		buttonPanel.add(panel3);
		buttonPanel.add(panel4); 
		buttonPanel.add(panel5);
		
		this.add(topPanel, BorderLayout.NORTH); 
		this.add(buttonPanel, BorderLayout.CENTER);
		//this.add(buttonPanel1,BorderLayout.CENTER);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	} 
	public void actionPerformed(ActionEvent aevt) {
		/**Object Selected = aevt.getSource();
		if(Selected.equals(button)) {
			WindowDemo demo = new WindowDemo(15, 15);
			this.setVisible(false);
		}
		if(Selected.equals(button2)) {
			WindowDemo demo = new WindowDemo(15, 15);
			this.setVisible(false);
		}
		
		// if resetting the squares' colours is requested then do so
		**/
	}
	
	public void mouseClicked(MouseEvent mevt)
	{
		// get the object that was selected in the 
		Object selected = mevt.getSource();
		if(selected.equals(button)) {
			//for color mode 1:
			color_tracker demo= new color_tracker();
			demo.set_color("Normal");
			demo.set_colorCODE("XXXX");
			demo.set_colorLIGHT("XXXX");
			demo.set_colorSAT("XXXX");
			demo.make_frame();
			this.setVisible(false); 
			
		}
		if(selected.equals(button1)) {
			//WindowDemo demo = new WindowDemo(15, 15);
			color_tracker demo= new color_tracker();
			demo.set_color("Deuteranopia");
			demo.set_colorCODE("XXXX");
			demo.set_colorLIGHT("XXXX");
			demo.set_colorSAT("XXXX");
			demo.make_frame();
			this.setVisible(false);
		}
		if(selected.equals(button2)) {
			color_tracker demo= new color_tracker();
			demo.set_color("Protanopia");
			demo.set_colorCODE("XXXX");
			demo.set_colorLIGHT("XXXX");
			demo.set_colorSAT("XXXX");
			demo.make_frame();
			this.setVisible(false);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		}
		if(selected.equals(button3)) {
			//this.setVisible(false);
			//this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			color_tracker demo= new color_tracker();
			demo.set_color("Tritanopia");
			demo.set_colorCODE("XXXX");
			demo.set_colorLIGHT("XXXX");
			demo.set_colorSAT("XXXX");
			demo.make_frame();
			this.setVisible(false);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		}
		if(selected.equals(button4)) {
			//this.setVisible(false);
			//this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			settings demo= new settings();
			this.setVisible(false);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		}
		
		//this.setVisible(false);
		
	}
	
	public void mouseEntered(MouseEvent arg0){
		Object selected = arg0.getSource();
		if(selected.equals(button)) {
			button.setBackground(Color.gray); 
		}
		if(selected.equals(button1)) {
			button1.setBackground(Color.gray); 
		}
		if(selected.equals(button2)) {
			button2.setBackground(Color.gray);
		} 
		if(selected.equals(button3)) {
			button3.setBackground(Color.gray);
		} 
		if(selected.equals(button4)) {
			button4.setBackground(Color.gray);
		} 
	}
	public void mouseExited(MouseEvent arg0) {
		//button.setBounds(195,170,200,50);
		Object selected = arg0.getSource();
		if(selected.equals(button)) {
			button.setBackground(Color.WHITE);
		}
		if(selected.equals(button1)) {
			button1.setBackground(Color.WHITE); 
		}
		if(selected.equals(button2)) {
			button2.setBackground(Color.WHITE);
		}
		if(selected.equals(button3)) {
			button3.setBackground(Color.WHITE);
		}
		if(selected.equals(button4)) {
			button4.setBackground(Color.WHITE);
		}
		
	}
	public void mousePressed(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}
	
}

	
	
