
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;
/*
 *  The main window of the gui.
 *  Notice that it extends JFrame - so we can add our own components.
 *  Notice that it implements ActionListener - so we can handle user input.
 *  This version also implements MouseListener to show equivalent functionality (compare with the other demo).
 *  @author mhatcher
 */
public class WindowDemo extends JFrame implements ActionListener, MouseListener
{
	// gui components that are contained in this frame:
	private JPanel topPanel, bottomPanel,anotherPanel;	// top and bottom panels in the main window
	private JLabel instructionLabel;		// a text label to tell the user what to do
	private JLabel infoLabel;            // a text label to show the coordinate of the selected square
    private JButton topButton;				// a 'reset' button to appear in the top panel
	private GridSquare [][] gridSquares;	// squares to appear in grid formation in the bottom panel
	private int rows,columns;				// the size of the grid
	private JButton Roll;
	private JLabel Dice;
	private JButton Comb1;
	private JButton Comb2;
	private JButton Comb3;
	private JButton Stop;
	private JLabel RollInfo;
	private HashMap<Integer,Integer> cords=new HashMap(); 
	private int xcordp1;
	private int xcordp2;
	private int x,y;
	private int xcordp3;
	private int xcordp4;
	
	private int xcordp5;
	private int xcordp6;
	private int p1,p2,p3,p4,p5,p6;
	private int p1f,p2f,p3f,p4f,p5f,p6f;
	private int startp1,startp2,startp3,startp4,startp5,startp6;
	private int runner_count=0; 
	private JButton b1=new JButton();
	private JButton b2=new JButton();
	private JButton b3=new JButton();
	private JButton b4=new JButton();
	private JButton b5=new JButton();
	private JButton b6=new JButton();
	private ArrayList<Integer>visitedy;
	private ArrayList<Integer>visitedx;
	private int counter = 0;
	private GridSquare prevsquare;
	private int prevx;
	private int prevy;
	private ArrayList<GridSquare> selectedSquares;
	/*
	 *  constructor method takes as input how many rows and columns of gridsquares to create
	 *  it then creates the panels, their subcomponents and puts them all together in the main frame
	 *  it makes sure that action listeners are added to selectable items
	 *  it makes sure that the gui will be visible
	 */
	public WindowDemo(int rows, int columns)
	{
		Border border1 = new LineBorder(Color.LIGHT_GRAY,1);
		this.rows = rows;
		this.columns = columns;
		this.setSize(800,800);
		
		visitedy=new ArrayList<Integer>();
		visitedx=new ArrayList<Integer>();
		Dice = new JLabel();
		RollInfo = new JLabel("RollInfo");
		Comb1 = new JButton("Comb1");
		Comb2 = new JButton("Comb2");
		Comb3 = new JButton("comb3");
		Stop = new JButton("STOP");
		
		Stop.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		Stop.setBackground(Color.RED);
		Stop.setForeground(Color.WHITE);
		Stop.setBorder(border1);
		Stop.setPreferredSize(new Dimension(100,50));
		
		Comb1.setBackground(Color.MAGENTA);
		Comb1.setForeground(Color.WHITE);
		Comb1.setBorder(border1);
		Comb1.setPreferredSize(new Dimension(80,50));
		Comb1.setFont(new Font("Comic Sans MS",Font.BOLD,13));
		
		Comb2.setBackground(Color.BLUE);
		Comb2.setForeground(Color.WHITE);
		Comb2.setBorder(border1);
		Comb2.setPreferredSize(new Dimension(80,50));
		Comb2.setFont(new Font("Comic Sans MS",Font.BOLD,13));
		
		Comb3.setBackground(Color.GREEN);
		Comb3.setForeground(Color.WHITE);
		Comb3.setBorder(border1);
		Comb3.setPreferredSize(new Dimension(80,50));
		Comb3.setFont(new Font("Comic Sans MS",Font.BOLD,13));
		
		b1.setBackground(Color.GREEN);
		b1.setForeground(Color.WHITE);
		b1.setBorder(border1);
		b1.setPreferredSize(new Dimension(80,50));
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,13)); 
		
		b2.setBackground(Color.GREEN);
		b2.setForeground(Color.WHITE);
		b2.setBorder(border1);
		b2.setPreferredSize(new Dimension(80,50));
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,13)); 
		
		b3.setBackground(Color.GREEN);
		b3.setForeground(Color.WHITE);
		b3.setBorder(border1);
		b3.setPreferredSize(new Dimension(80,50));
		b3.setFont(new Font("Comic Sans MS",Font.BOLD,13)); 
		
		b4.setBackground(Color.GREEN);
		b4.setForeground(Color.WHITE);
		b4.setBorder(border1);
		b4.setPreferredSize(new Dimension(80,50));
		b4.setFont(new Font("Comic Sans MS",Font.BOLD,13)); 
		
		b5.setBackground(Color.GREEN);
		b5.setForeground(Color.WHITE);
		b5.setBorder(border1);
		b5.setPreferredSize(new Dimension(80,50));
		b5.setFont(new Font("Comic Sans MS",Font.BOLD,13)); 
		
		b6.setBackground(Color.GREEN);
		b6.setForeground(Color.WHITE);
		b6.setBorder(border1);
		b6.setPreferredSize(new Dimension(80,50));
		b6.setFont(new Font("Comic Sans MS",Font.BOLD,13));
		
		ImageIcon icon=new ImageIcon(this.getClass().getResource("dice1.jpg"));
		
		Dice.setIcon(icon);
		// first create the panels
		topPanel = new JPanel();
		anotherPanel = new JPanel();
		
		topPanel.setLayout(new FlowLayout());
		Roll = new JButton("Roll");
		bottomPanel = new JPanel();
		bottomPanel.setLayout(new GridLayout(rows, columns));
		bottomPanel.setSize(500,500);
		
		Roll.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		Roll.setBackground(Color.ORANGE);
		Roll.setForeground(Color.WHITE);
		Roll.setBorder(border1);
		Roll.setPreferredSize(new Dimension(100,50));
		anotherPanel.setLayout(new FlowLayout());
		anotherPanel.add(Roll);
		anotherPanel.setBackground(Color.GRAY);
		anotherPanel.add(Dice);
		Roll.addActionListener(this);
		Comb1.addActionListener(this);
		Comb2.addActionListener(this);
		Comb3.addActionListener(this);
		Stop.addActionListener(this);
		// then create the components for each panel and add them to it
		
		// for the top panel:
		instructionLabel = new JLabel("Click the Squares!");
        infoLabel = new JLabel("No square clicked yet.");
		topButton = new JButton("Reset");
		topButton.addActionListener(this);			// IMPORTANT! Without this, clicking the square does nothing.
		
		topPanel.add(instructionLabel);
		topPanel.add (topButton);
        topPanel.add(infoLabel);
        Border border= new LineBorder(new Color(0x803222),1);
	
		// for the bottom panel:	
		// create the squares and add them to the grid
		gridSquares = new GridSquare[rows][columns];
		for ( int x = 0; x < columns; x ++)
		{
			for ( int y = 0; y < rows; y ++)
			{
				gridSquares[x][y] = new GridSquare(x, y);
				gridSquares[x][y].setSize(20, 20);
				gridSquares[x][y].setBackground(Color.GRAY);
				//gridSquares[x][y].setBorder(border);
				gridSquares[x][y].addMouseListener(this);		// AGAIN, don't forget this line!
				
				bottomPanel.add(gridSquares[x][y]);
			}
		} 
		
		cords.put(7, 12);
		cords.put(6, 11);
		cords.put(8, 11);
		cords.put(5, 10);
		cords.put(9, 10);
		cords.put(4, 9);
		cords.put(10, 9);
		cords.put(3, 8);
		cords.put(11, 8);
		cords.put(2, 7);
		cords.put(12, 7);
		
		
		ArrayList indc=new ArrayList();
		//change colors 
		indc.add(0);
		indc.add(1);
		indc.add(2);
		indc.add(11);
		indc.add(12);
		indc.add(13);
		indc.add(14);
		ArrayList indc2=new ArrayList();
		
		indc2.add(0);
		indc2.add(1);
		indc2.add(2);
		indc2.add(3);
		indc2.add(10);
		indc2.add(11);
		indc2.add(12);
		indc2.add(13);
		indc2.add(14); 
		
		ArrayList indc3=new ArrayList();
		
		indc3.add(0);
		indc3.add(1);
		indc3.add(2);
		indc3.add(3);
		indc3.add(4);
		indc3.add(9);
		indc3.add(10);
		indc3.add(11);
		indc3.add(12);
		indc3.add(13);
		indc3.add(14); 
		
		ArrayList indc4=new ArrayList();
		
		indc4.add(0);
		indc4.add(1);
		indc4.add(2);
		indc4.add(3);
		indc4.add(4);
		indc4.add(5);
		indc4.add(8);
		indc4.add(9);
		indc4.add(10);
		indc4.add(11);
		indc4.add(12);
		indc4.add(13);
		indc4.add(14); 
		
		for ( int z = 0; z < columns; z++)
		{
			for ( int d = 0; d< rows; d++)
			{   
				if(z==0&&d==7) {
					gridSquares[z][d].setlabel("7");
				}
				else if(z!=0&&z!=13&&z!=14&&d==7) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==1&&d==6) {
					gridSquares[z][d].setlabel("6");
				}
				else if(z!=0&&z!=1&&z!=12&&z!=13&&z!=14&&d==6) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==1&&d==8) {
					gridSquares[z][d].setlabel("8");
				}
				if(z==8&&d==2) {
					gridSquares[z][d].setlabel("C");
				}
				if(z==9&&d==3) {
					gridSquares[z][d].setlabel("A");
				}
				if(z==10&&d==4) {
					gridSquares[z][d].setlabel("N");
				}
				if(z==11&&d==5) {
					gridSquares[z][d].setlabel("'T");
				}
				if(z==11&&d==9) {
					gridSquares[z][d].setlabel("S");
				}
				if(z==10&&d==10) {
					gridSquares[z][d].setlabel("T");
				}
				if(z==9&&d==11) {
					gridSquares[z][d].setlabel("O");
				}
				if(z==8&&d==12) {
					gridSquares[z][d].setlabel("P");
				}
			
				if(z!=0&&z!=1&&z!=12&&z!=13&&z!=14&&d==8) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==2&&d==5) {
					gridSquares[z][d].setlabel("5");
				}
				if((!indc.contains(z))&& d==5) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==2&&d==9) {
					gridSquares[z][d].setlabel("9");
				}
				if((!indc.contains(z))&& d==9) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==3&&d==4) {
					gridSquares[z][d].setlabel("4");
				}
				if((!indc2.contains(z))&&d==4) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==3&&d==10) {
					gridSquares[z][d].setlabel("10");
				}
				if((!indc2.contains(z))&&d==10) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==4&&d==3) {
					gridSquares[z][d].setlabel("3");
				}
				if((!indc3.contains(z))&&d==3) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==4&&d==11) {
					gridSquares[z][d].setlabel("11");
				}
				if((!indc3.contains(z))&&d==11) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==5&&d==2) {
					gridSquares[z][d].setlabel("2");
				}
				if((!indc4.contains(z))&&d==2) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==5&&d==12) {
					gridSquares[z][d].setlabel("12");
				}
				if((!indc4.contains(z))&&d==12) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				
			}
		}
		
		
		// now add the top and bottom panels to the main frame
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(topPanel, BorderLayout.NORTH);
		getContentPane().add(bottomPanel, BorderLayout.CENTER);		// needs to be center or will draw too small
		getContentPane().add(anotherPanel, BorderLayout.SOUTH);
		// housekeeping : behaviour
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(true); 
		setVisible(true);
	}
	
	
	/*
	 *  handles actions performed in the gui
	 *  this method must be present to correctly implement the ActionListener interface
	 */
	public void actionPerformed(ActionEvent aevt)
	{ 
		// get the object that was selected in the gui
		Object selected = aevt.getSource();
		Border border= new LineBorder(new Color(0x803222),1);
		
		Boolean MaxCube = false;
		
		if(selected.equals(Roll)) {
			counter++;
			
			Roll diceRoll1= new Roll();
			diceRoll1.MakeRoll();
			Comb1.setText(diceRoll1.getComb1());
			Comb2.setText(diceRoll1.getComb2());
			Comb3.setText(diceRoll1.getComb3());
			xcordp1=diceRoll1.getPair1();
			xcordp2=diceRoll1.getPair2();
			xcordp3=diceRoll1.getPair3();
			xcordp4=diceRoll1.getPair4();
			xcordp5=diceRoll1.getPair5();
			xcordp6=diceRoll1.getPair6(); 
			p1=xcordp1; //x val
			p2=xcordp2;
			startp1=cords.get(p1);//yval
			startp2=cords.get(p2); 
			
			p3=xcordp3; //x val
			p4=xcordp4;
			startp3=cords.get(p3);//yval
			startp4=cords.get(p4); 
			
			p5=xcordp5; //x val
			p6=xcordp6;
			startp5=cords.get(p5);//yval
			startp6=cords.get(p6); 
			
						
			RollInfo.setText("You rolled "+diceRoll1.getDice1()+", "+diceRoll1.getDice2()+", "+diceRoll1.getDice3()+", "+diceRoll1.getDice4()+" . pick one combination ");
			RollInfo.setForeground(Color.white);
			RollInfo.setFont(new Font("Comic Sans MS",Font.BOLD,13));
			anotherPanel.add(RollInfo);
			anotherPanel.add(Comb1);
			anotherPanel.add(Comb2);
			anotherPanel.add(Comb3);
			anotherPanel.add(Stop);
			Comb1.setVisible(true);
			Comb2.setVisible(true);
			Comb3.setVisible(true);
			Stop.setVisible(false);
			getContentPane().add(anotherPanel, BorderLayout.SOUTH);
			setVisible(true); 
			/*if(MaxCube) {
				if(!visited.contains(p1)||!visited.contains(p2)||!visited.contains(p3)||!visited.contains(p4)||!visited.contains(p5)||!visited.contains(p6)) {
					RollInfo.setText("You Bust");
					
				}
			}*/
			
			
		}		
		else if ( selected.equals(Stop) )
		{
			for ( int z = 0; z < columns; z++)
			{
				for ( int d = 0; d< rows; d++)
				{
					if(gridSquares[z][d].getBackground().equals(Color.WHITE)) {
						gridSquares[z][d].setBackground(Color.BLUE);
					}
				}
			}
		}
		else if(selected.equals(Comb1)) {
			Comb1.setVisible(false);
			Comb2.setVisible(false);
			Comb3.setVisible(false);
			RollInfo.setText("You selected "+Comb1.getText()+" . Move cubes in valid columns or ");
			Stop.setVisible(true);
			}
			
		else if(selected.equals(Comb2)) {
			Comb1.setVisible(false);
			Comb2.setVisible(false);
			Comb3.setVisible(false);
			RollInfo.setText("You selected "+Comb2.getText()+" . Move cubes in those columns or");
			Stop.setVisible(true);
		}
		else if(selected.equals(Comb3)) {
			Comb1.setVisible(false);
			Comb2.setVisible(false);
			Comb3.setVisible(false);
			RollInfo.setText("You selected "+Comb3.getText()+" . Move cubes in those columns or");
			Stop.setVisible(true); }
			
			
		
		
		// if resetting the squares' colours is requested then do so
		else if ( selected.equals(topButton) )
		{
			for ( int x1 = 0; x1 < columns; x1 ++)
			{
				for ( int y = 0; y < rows; y ++)
				{
					//gridSquares [x][y].setColor(x + y);
				}
			}
		}
	
	}

	// Mouse Listener events
	public void mouseClicked(MouseEvent mevt)
	{
		// get the object that was selected in the gui
		Object selected = mevt.getSource();
		
		/*
		 * I'm using instanceof here so that I can easily cover the selection of any of the gridsquares
		 * with just one piece of code.
		 * In a real system you'll probably have one piece of action code per selectable item.
		 * Later in the course we'll see that the Command Holder pattern is a much smarter way to handle actions.
		 */
		
		// if a gridsquare is selected then switch its color
		if (prevsquare!= null) {
			prevx = prevsquare.getXcoord();
            prevy = prevsquare.getYcoord();
			
				
		}
		if (selected instanceof GridSquare)
		{
            GridSquare square = (GridSquare) selected;
			
			for ( int x = 0; x < columns; x++)
			{
				for ( int y = 0; y < rows; y++)
				{
					if(gridSquares [x][y].getBackground().equals(Color.WHITE)){
						visitedx.add(x);
						visitedy.add(y);
					if(y==square.getYcoord()){
						gridSquares [x][y].setBackground(new Color(0xC74F36));
					}
					}
				}
			} 
			
			square.setBackground(Color.WHITE);
			
            x = square.getXcoord();
            y = square.getYcoord();
            
            
            prevsquare = square;
            
		}	
		
	}
	
	// not used but must be present to fulfil MouseListener contract
	public void mouseEntered(MouseEvent arg0){}
	public void mouseExited(MouseEvent arg0) {}
	public void mousePressed(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}
	
	}

	 
