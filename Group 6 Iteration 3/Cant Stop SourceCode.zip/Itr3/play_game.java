

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class play_game extends JFrame implements ActionListener, MouseListener{
	JLabel header= new JLabel();
	JLabel med_text= new JLabel();
	JLabel bot_text= new JLabel();
	JButton button = new JButton();
	JButton button1 = new JButton();
	JButton button2 = new JButton();
	JButton button3 = new JButton(); 
	JButton button4= new JButton();
	
	public play_game(){
		this.setSize(600,700);
		this.setTitle("Play Game");
		this.getContentPane().setBackground(new Color(0x16A4DD));
		this.setLayout(new BorderLayout());
		this.setVisible(true); 
		header.setText(" Can't");
		header.setFont(new Font("Comic Sans MS",Font.BOLD,46)); 
		header.setForeground(Color.white); 
		
		Border border= new LineBorder(Color.BLACK,6);
		
		//button1.setAlignmentY(Component.TOP_ALIGNMENT);
		//button4.setPreferredSize(new Dimension(100,50));
	
		
		
		JPanel topPanel= new JPanel();
		topPanel.setLayout(new BoxLayout(topPanel,BoxLayout.Y_AXIS));
		topPanel.add(Box.createVerticalStrut(30));
		topPanel.setBackground(new Color(0x16A4DD));
		header.setAlignmentX(Component.CENTER_ALIGNMENT);
		topPanel.add(header); 
		med_text.setText("Stop");
		med_text.setFont(new Font("Comic Sans MS",Font.BOLD,46)); 
		med_text.setAlignmentX(Component.CENTER_ALIGNMENT);
		med_text.setForeground(Color.white); 
		
		bot_text.setText("Play Game");
		bot_text.setFont(new Font("Comic Sans MS",Font.BOLD,46)); 
		bot_text.setAlignmentX(Component.CENTER_ALIGNMENT);
		bot_text.setForeground(Color.BLACK);
		
		topPanel.add(med_text);
		topPanel.add(bot_text);
		topPanel.setBorder(BorderFactory.createEmptyBorder(20,20,40,20));
		
		
		//button.setBounds(195,170,00,50);
		button.setText("New Game"); 
		button.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button.setBackground(Color.white); 
		button.setBorder(border);
		button.setAlignmentY(Component.TOP_ALIGNMENT);
		button.setPreferredSize(new Dimension(200,50)); 
		button.addMouseListener(this); 
		
		button1.setText("Load Game"); 
		button1.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button1.setBackground(Color.white); 
		button1.setBorder(border);
		//button1.setAlignmentY(Component.TOP_ALIGNMENT);
		button1.setPreferredSize(new Dimension(200,50)); 
		button1.addMouseListener(this);
		
 
		
		button4.setText("Back"); 
		button4.setBounds(155, 50, 100, 50);
		button4.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button4.setBackground(Color.white); 
		button4.setBorder(border);
		button4.setPreferredSize(new Dimension(100,50));
		button4.addMouseListener(this);
		
	
		JPanel buttonPanel= new JPanel(new FlowLayout(FlowLayout.CENTER));
		JPanel buttonPanel1= new JPanel();
		buttonPanel.setBackground(new Color(0x16A4DD)); 
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
		buttonPanel.add(button);
		buttonPanel.add(button1);  
		
		
		JPanel panel1= new JPanel();
		panel1.setBackground(new Color(0x16A4DD));
		panel1.setPreferredSize(new Dimension(50,50)); 
		panel1.add(button); 
		
		JPanel panel2= new JPanel();
		panel2.setPreferredSize(new Dimension(50,50)); 
		panel2.setBackground(new Color(0x16A4DD));
		panel2.add(button1); 
		
		JPanel panel3= new JPanel();
		panel3.setPreferredSize(new Dimension(50,50)); 
		panel3.setBackground(new Color(0x16A4DD));
	
		
		JPanel panel4= new JPanel();
		//panel4.setLayout(new BorderLayout());
		panel4.setPreferredSize(new Dimension(50,50)); 
		panel4.setBackground(new Color(0x16A4DD));
		//panel4.add(button4, BorderLayout.WEST);  
		
		JPanel panel5= new JPanel(new FlowLayout(FlowLayout.LEFT));
		//panel4.setLayout(new BorderLayout());
		panel5.setPreferredSize(new Dimension(50,50)); 
		panel5.setBackground(new Color(0x16A4DD));
		panel5.add(button4); 
		
		
		
		buttonPanel.add(panel1); 
		buttonPanel.add(panel2); 
		buttonPanel.add(panel3);
		buttonPanel.add(panel4); 
		buttonPanel.add(panel5);
		
		this.add(topPanel, BorderLayout.NORTH); 
		this.add(buttonPanel, BorderLayout.CENTER);
		//this.add(buttonPanel1,BorderLayout.CENTER);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	} 
	public void actionPerformed(ActionEvent aevt) {
		/**Object Selected = aevt.getSource();
		if(Selected.equals(button)) {
			WindowDemo demo = new WindowDemo(15, 15);
			this.setVisible(false);
		}
		if(Selected.equals(button2)) {
			WindowDemo demo = new WindowDemo(15, 15);
			this.setVisible(false);
		}
		
		// if resetting the squares' colours is requested then do so
		**/
	}
	
	public void mouseClicked(MouseEvent mevt)
	{
		// get the object that was selected in the 
		Object selected = mevt.getSource();
		if(selected.equals(button)) {
			player_settings demo=new player_settings();
			this.setVisible(false); 
			
		}
		if(selected.equals(button4)) {
			//this.setVisible(false);
			//this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			homepage demo= new homepage();
			this.setVisible(false);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		}
		
		//this.setVisible(false);
		
	}
	
	public void mouseEntered(MouseEvent arg0){
		Object selected = arg0.getSource();
		if(selected.equals(button)) {
			button.setBackground(Color.gray);
		}
		if(selected.equals(button1)) {
			button1.setBackground(Color.gray);
		}
		if(selected.equals(button4)) {
			button4.setBackground(Color.gray);
		}
	}
	public void mouseExited(MouseEvent arg0) {
		//button.setBounds(195,170,200,50);
		Object selected = arg0.getSource();
		if(selected.equals(button)) {
			button.setBackground(Color.WHITE);
		}
		if(selected.equals(button1)) {
			button1.setBackground(Color.WHITE);
		}
		if(selected.equals(button4)) {
			button4.setBackground(Color.WHITE);
		}
		
	}
	public void mousePressed(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}
	
}


