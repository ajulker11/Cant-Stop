
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

/*
 *  The main window of the gui.
 *  Notice that it extends JFrame - so we can add our own components.
 *  Notice that it implements ActionListener - so we can handle user input.
 *  This version also implements MouseListener to show equivalent functionality (compare with the other demo).
 *  @author mhatcher
 */
public class WindowDemo extends JFrame implements ActionListener, MouseListener
{
	// gui components that are contained in this frame:
	private JPanel topPanel, bottomPanel;	// top and bottom panels in the main window
	private JLabel instructionLabel;		// a text label to tell the user what to do
	private JLabel infoLabel;            // a text label to show the coordinate of the selected square
    private JButton topButton;				// a 'reset' button to appear in the top panel
	private GridSquare [][] gridSquares;	// squares to appear in grid formation in the bottom panel
	private int rows,columns;				// the size of the grid
	
	/*
	 *  constructor method takes as input how many rows and columns of gridsquares to create
	 *  it then creates the panels, their subcomponents and puts them all together in the main frame
	 *  it makes sure that action listeners are added to selectable items
	 *  it makes sure that the gui will be visible
	 */
	public WindowDemo(int rows, int columns)
	{
		this.rows = rows;
		this.columns = columns;
		this.setSize(600,600);
		
		// first create the panels
		topPanel = new JPanel();
		topPanel.setLayout(new FlowLayout());
		
		bottomPanel = new JPanel();
		bottomPanel.setLayout(new GridLayout(rows, columns));
		bottomPanel.setSize(500,500);
		
		// then create the components for each panel and add them to it
		
		// for the top panel:
		instructionLabel = new JLabel("Click the Squares!");
        infoLabel = new JLabel("No square clicked yet.");
		topButton = new JButton("Reset");
		topButton.addActionListener(this);			// IMPORTANT! Without this, clicking the square does nothing.
		
		topPanel.add(instructionLabel);
		topPanel.add (topButton);
        topPanel.add(infoLabel);
        Border border= new LineBorder(new Color(0x803222),1);
	
		// for the bottom panel:	
		// create the squares and add them to the grid
		gridSquares = new GridSquare[rows][columns];
		for ( int x = 0; x < columns; x ++)
		{
			for ( int y = 0; y < rows; y ++)
			{
				gridSquares[x][y] = new GridSquare(x, y);
				gridSquares[x][y].setSize(20, 20);
				gridSquares[x][y].setBackground(Color.GRAY);
				//gridSquares[x][y].setBorder(border);
				gridSquares[x][y].addMouseListener(this);		// AGAIN, don't forget this line!
				
				bottomPanel.add(gridSquares[x][y]);
			}
		} 
		ArrayList indc=new ArrayList();
		//change colors 
		indc.add(0);
		indc.add(1);
		indc.add(2);
		indc.add(11);
		indc.add(12);
		indc.add(13);
		indc.add(14);
		ArrayList indc2=new ArrayList();
		
		indc2.add(0);
		indc2.add(1);
		indc2.add(2);
		indc2.add(3);
		indc2.add(10);
		indc2.add(11);
		indc2.add(12);
		indc2.add(13);
		indc2.add(14); 
		
		ArrayList indc3=new ArrayList();
		
		indc3.add(0);
		indc3.add(1);
		indc3.add(2);
		indc3.add(3);
		indc3.add(4);
		indc3.add(9);
		indc3.add(10);
		indc3.add(11);
		indc3.add(12);
		indc3.add(13);
		indc3.add(14); 
		
		ArrayList indc4=new ArrayList();
		
		indc4.add(0);
		indc4.add(1);
		indc4.add(2);
		indc4.add(3);
		indc4.add(4);
		indc4.add(5);
		indc4.add(8);
		indc4.add(9);
		indc4.add(10);
		indc4.add(11);
		indc4.add(12);
		indc4.add(13);
		indc4.add(14); 
		
		for ( int z = 0; z < columns; z++)
		{
			for ( int d = 0; d< rows; d++)
			{   
				if(z==0&&d==7) {
					gridSquares[z][d].setlabel("7");
				}
				else if(z!=0&&z!=13&&z!=14&&d==7) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==1&&d==6) {
					gridSquares[z][d].setlabel("6");
				}
				else if(z!=0&&z!=1&&z!=12&&z!=13&&z!=14&&d==6) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==1&&d==8) {
					gridSquares[z][d].setlabel("8");
				}
				if(z==8&&d==2) {
					gridSquares[z][d].setlabel("C");
				}
				if(z==9&&d==3) {
					gridSquares[z][d].setlabel("A");
				}
				if(z==10&&d==4) {
					gridSquares[z][d].setlabel("N");
				}
				if(z==11&&d==5) {
					gridSquares[z][d].setlabel("'T");
				}
				if(z==11&&d==9) {
					gridSquares[z][d].setlabel("S");
				}
				if(z==10&&d==10) {
					gridSquares[z][d].setlabel("T");
				}
				if(z==9&&d==11) {
					gridSquares[z][d].setlabel("O");
				}
				if(z==8&&d==12) {
					gridSquares[z][d].setlabel("P");
				}
			
				if(z!=0&&z!=1&&z!=12&&z!=13&&z!=14&&d==8) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==2&&d==5) {
					gridSquares[z][d].setlabel("5");
				}
				if((!indc.contains(z))&& d==5) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==2&&d==9) {
					gridSquares[z][d].setlabel("9");
				}
				if((!indc.contains(z))&& d==9) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==3&&d==4) {
					gridSquares[z][d].setlabel("4");
				}
				if((!indc2.contains(z))&&d==4) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==3&&d==10) {
					gridSquares[z][d].setlabel("10");
				}
				if((!indc2.contains(z))&&d==10) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==4&&d==3) {
					gridSquares[z][d].setlabel("3");
				}
				if((!indc3.contains(z))&&d==3) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==4&&d==11) {
					gridSquares[z][d].setlabel("11");
				}
				if((!indc3.contains(z))&&d==11) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==5&&d==2) {
					gridSquares[z][d].setlabel("2");
				}
				if((!indc4.contains(z))&&d==2) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				if(z==5&&d==12) {
					gridSquares[z][d].setlabel("12");
				}
				if((!indc4.contains(z))&&d==12) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
				}
				
			}
		}
		
		
		// now add the top and bottom panels to the main frame
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(topPanel, BorderLayout.NORTH);
		getContentPane().add(bottomPanel, BorderLayout.CENTER);		// needs to be center or will draw too small
		
		// housekeeping : behaviour
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(true);
		setVisible(true);
	}
	
	
	/*
	 *  handles actions performed in the gui
	 *  this method must be present to correctly implement the ActionListener interface
	 */
	public void actionPerformed(ActionEvent aevt)
	{
		// get the object that was selected in the gui
		Object selected = aevt.getSource();
				
		// if resetting the squares' colours is requested then do so
		if ( selected.equals(topButton) )
		{
			for ( int x = 0; x < columns; x ++)
			{
				for ( int y = 0; y < rows; y ++)
				{
					//gridSquares [x][y].setColor(x + y);
				}
			}
		}
	}


	// Mouse Listener events
	public void mouseClicked(MouseEvent mevt)
	{
		// get the object that was selected in the gui
		Object selected = mevt.getSource();
		
		/*
		 * I'm using instanceof here so that I can easily cover the selection of any of the gridsquares
		 * with just one piece of code.
		 * In a real system you'll probably have one piece of action code per selectable item.
		 * Later in the course we'll see that the Command Holder pattern is a much smarter way to handle actions.
		 */
		
		// if a gridsquare is selected then switch its color
		if (selected instanceof GridSquare)
		{
            GridSquare square = (GridSquare) selected;
			//square.switchColor();
            int x = square.getXcoord();
            int y = square.getYcoord();
            infoLabel.setText("("+x+","+y+") last selected.");
            
		}	
	}
	
	// not used but must be present to fulfil MouseListener contract
	public void mouseEntered(MouseEvent arg0){}
	public void mouseExited(MouseEvent arg0) {}
	public void mousePressed(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}
}

