

public class Driver {
	public static void main(String[] args)
	{
		// create a new GUI window
		//WindowDemo demo = new WindowDemo(15, 15); 
		homepage demo = new homepage();
	}

}

