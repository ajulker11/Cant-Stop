
import java.awt.*;
import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.awt.event.MouseListener;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.EventObject;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class homepage extends JFrame implements ActionListener, MouseListener
{
	JButton button = new JButton();
	JButton button2 = new JButton();
	JButton button3 = new JButton();
	public homepage() {
		
		Border border1a=new LineBorder(new Color(0x16A4DD));
		JButton button1a = new JButton();
		button1a.setBounds(0,50,50,100);
		//button1a.setText("GAME OF CAN'T STOP");
		//button1a.setForeground(Color.white);
		//button1a.setFont(new Font("Ariel",Font.BOLD,36)); 
		button1a.setBackground(new Color(0x16A4DD));
		button1a.setBorder(border1a);
		
		Border border1=new LineBorder(new Color(0x16A4DD));
		JButton button1 = new JButton();
		button1.setBounds(80,60,450,100);
		button1.setText("GAME OF CAN'T STOP");
		button1.setForeground(Color.white);
		button1.setFont(new Font("Comic Sans MS",Font.BOLD,36)); 
		button1.setBackground(new Color(0x16A4DD));
		button1.setBorder(border1);
		//button1.addMouseListener(this);
		
		Border border= new LineBorder(Color.BLACK,6);
		button.setBounds(175,200,250,50);
		button.setText("Set-Up a Game"); 
		button.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button.setBackground(Color.white);
		button.setBorder(border);
		button.addMouseListener(this); 
		//button.addActionListener(this);
	
		JPanel panel=new JPanel(); 
		
		button2.setBounds(175,300,250,50);
		button2.setText("Settings"); 
		button2.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button2.setBackground(Color.white);
		button2.setBorder(border);
		button2.addMouseListener(this);
		//button2.addActionListener(this);
		
		button3.setBounds(175,400,250,50);
		button3.setText("Quit"); 
		button3.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button3.setBackground(Color.white);
		button3.setBorder(border);
		button3.addMouseListener(this);
		
		JLabel label= new JLabel();
		label.setText("GAME OF CAN'T STOP");
		label.setForeground(Color.WHITE);
		
		
		//panel.add(label);

		
		this.setLayout(null);
		this.setTitle("Can't Stop");
		this.getContentPane().setBackground(new Color(0x16A4DD));
		this.setSize(600,700);
		//this.add(label);
		this.add(button1a);
		this.add(button1);
		this.add(button);
		//this.add(panel);
		this.add(button2);
		this.add(button3);
		
		
		this.setVisible(true);
		
	}
	
	public void actionPerformed(ActionEvent aevt) {
		/**Object Selected = aevt.getSource();
		if(Selected.equals(button)) {
			WindowDemo demo = new WindowDemo(15, 15);
			this.setVisible(false);
		}
		if(Selected.equals(button2)) {
			WindowDemo demo = new WindowDemo(15, 15);
			this.setVisible(false);
		}
		
		// if resetting the squares' colours is requested then do so
		**/
	}
	
	public void mouseClicked(MouseEvent mevt)
	{
		// get the object that was selected in the 
		Object selected = mevt.getSource();
		if(selected.equals(button)) {
			play_game demo=new play_game();
			this.setVisible(false);
		}
		if(selected.equals(button2)) {
			settings demo = new settings();
			this.setVisible(false);
		}
		if(selected.equals(button3)) {
			this.setVisible(false);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		}
		
		//this.setVisible(false);
		
	}
	
	public void mouseEntered(MouseEvent arg0){
		Object selected = arg0.getSource();
		if(selected.equals(button)) {
			button.setBounds(165,195,275,65);
		}
		if(selected.equals(button2)) {
			button2.setBounds(165,295,275,65);
		}
		if(selected.equals(button3)) {
			button3.setBounds(165,395,275,65);
		}
	}
	public void mouseExited(MouseEvent arg0) {
		//button.setBounds(195,170,200,50);
		Object selected = arg0.getSource();
		if(selected.equals(button)) {
			button.setBounds(175,200,250,50);
		}
		if(selected.equals(button2)) {
			button2.setBounds(175,300,250,50);
		}
		if(selected.equals(button3)) {
			button3.setBounds(175,400,250,50);
		}
		
	}
	public void mousePressed(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}
	

}


