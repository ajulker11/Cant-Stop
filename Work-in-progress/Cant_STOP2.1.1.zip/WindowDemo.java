
import java.awt.*;
import java.awt.event.*;

import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
/*
 *  The main window of the gui.
 *  Notice that it extends JFrame - so we can add our own components.
 *  Notice that it implements ActionListener - so we can handle user input.
 *  This version also implements MouseListener to show equivalent functionality (compare with the other demo).
 *  @author mhatcher
 */
public class WindowDemo extends JFrame implements ActionListener, MouseListener
{
	// gui components that are contained in this frame:
	private JPanel topPanel, bottomPanel,anotherPanel;	// top and bottom panels in the main window
	private JLabel instructionLabel;		// a text label to tell the user what to do
	private JLabel infoLabel  , PlayerLabel;            // a text label to show the coordinate of the selected square
    private JButton topButton, Bust, Save, Close,claim;				// a 'reset' button to appear in the top panel
	private GridSquare [][] gridSquares;	// squares to appear in grid formation in the bottom panel
	private GridSquare2 [][] gridSquares2;
	private int rows,columns;				// the size of the grid
	private JButton Roll;
	private JLabel Dice;
	private JButton Comb1;
	private JButton Comb2;
	private JButton Comb3;
	private JButton Stop;
	private JLabel RollInfo;
	private HashMap<Integer,Integer> cords=new HashMap(); 
	private int white_count=0;
	private ArrayList<Integer>visitedy;
	private ArrayList<Integer>visitedx;
	
	private GridSquare prevsquare;
	private int prevx;
	private int prevy;
	private ArrayList<GridSquare> selectedSquares;
	private int x,y;
	private ArrayList indc=new ArrayList();
	private ArrayList indc2=new ArrayList();
	private ArrayList indc3=new ArrayList();
	private ArrayList indc4=new ArrayList();
	Player player = Player.PlayerSingleton(); 
	private int playerID;
	private int TotalPlayers = player.getNumPlayers();
	private int ClaimCount1=0;
	private int ClaimCount2=0;
	private int ClaimCount3=0;
	private int ClaimCount4=0;
	private int winner=0;
	/*
	 *  constructor method takes as input how many rows and columns of gridsquares to create
	 *  it then creates the panels, their subcomponents and puts them all together in the main frame
	 *  it makes sure that action listeners are added to selectable items
	 *  it makes sure that the gui will be visible
	 */
	public WindowDemo(int rows, int columns)
	{
		Border border1 = new LineBorder(Color.LIGHT_GRAY,1);
		this.rows = rows;
		this.columns = columns;
		this.setSize(1000,1200);
		
		//initialise player;
		playerID = 1;
		visitedy=new ArrayList<Integer>();
		visitedx=new ArrayList<Integer>();
		Dice = new JLabel();
		RollInfo = new JLabel("RollInfo");
		Comb1 = new JButton("Comb1");
		Comb2 = new JButton("Comb2");
		Comb3 = new JButton("comb3");
		Stop = new JButton("STOP");
		Stop.setFont(new Font("Comic Sans MS",Font.BOLD,13));
		Stop.setBackground(new Color(0xFF0000));
		Stop.setForeground(Color.WHITE);
		Stop.setBorder(border1);
		Stop.setPreferredSize(new Dimension(80,30));
		
		Comb1.setBackground(new Color(0xDC267F));
		Comb1.setForeground(Color.WHITE);
		Comb1.setBorder(border1);
		Comb1.setPreferredSize(new Dimension(80,50));
		Comb1.setFont(new Font("Comic Sans MS",Font.BOLD,13));
		
		Comb2.setBackground(new Color(0x648FFF));
		Comb2.setForeground(Color.WHITE);
		Comb2.setBorder(border1);
		Comb2.setPreferredSize(new Dimension(80,50));
		Comb2.setFont(new Font("Comic Sans MS",Font.BOLD,13));
		
		Comb3.setBackground(new Color(0x785EF0));
		Comb3.setForeground(Color.WHITE);
		Comb3.setBorder(border1);
		Comb3.setPreferredSize(new Dimension(80,50));
		Comb3.setFont(new Font("Comic Sans MS",Font.BOLD,13));
		
		
		
		ImageIcon icon=new ImageIcon(this.getClass().getResource("dice1.jpg"));
		
		Dice.setIcon(icon);
		// first create the panels
		topPanel = new JPanel();
		anotherPanel = new JPanel();
		
		
		Roll = new JButton("ROLL");
		bottomPanel = new JPanel();
		bottomPanel.setLayout(new GridLayout(rows, columns));
		bottomPanel.setSize(500,500);
		
		Roll.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		Roll.setBackground(new Color(0xFE6100));
		Roll.setForeground(Color.WHITE);
		Roll.setBorder(border1);
		Roll.setPreferredSize(new Dimension(100,50));
		anotherPanel.setLayout(new FlowLayout());
		anotherPanel.add(Roll);
		anotherPanel.setBackground(Color.GRAY);
		anotherPanel.add(Dice);
		Roll.addActionListener(this);
		Comb1.addActionListener(this);
		Comb2.addActionListener(this);
		Comb3.addActionListener(this);
		Stop.addActionListener(this);
		// then create the components for each panel and add them to it
		
		// for the top panel:
		instructionLabel = new JLabel("Click the Squares! based on roll and for new game click here -->");
        infoLabel = new JLabel("If you want to stop and end turn, click Stop --> ");
       
        PlayerLabel = new JLabel("Total players: "+player.getNumPlayers());
        instructionLabel.setFont(new Font("Comic Sans MS",Font.BOLD,13));
        infoLabel.setFont(new Font("Comic Sans MS",Font.BOLD,13));
        
        PlayerLabel.setFont(new Font("Comic Sans MS",Font.BOLD,13));
        
		topButton = new JButton("New Game");
		topButton.addActionListener(this);			// IMPORTANT! Without this, clicking the square does nothing.
		topButton.setFont(new Font("Comic Sans MS",Font.BOLD,13));
		topButton.setBackground(new Color(0xFE6100));
		topButton.setForeground(Color.WHITE);
		topButton.setBorder(border1);
		topButton.setPreferredSize(new Dimension(80,30));
		
		//bust button
		Bust = new JButton("BUST");
		Bust.addActionListener(this);			
		Bust.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		Bust.setBackground(Color.RED);
		Bust.setForeground(Color.WHITE);
		Bust.setBorder(border1);
		Bust.setPreferredSize(new Dimension(100,50));
		
		
		//save
		Save = new JButton("Save Game");
		Save.addActionListener(this);			// IMPORTANT! Without this, clicking the square does nothing.
		Save.setFont(new Font("Comic Sans MS",Font.BOLD,13));
		Save.setBackground(Color.GREEN);
		Save.setForeground(Color.WHITE);
		Save.setBorder(border1);
		Save.setPreferredSize(new Dimension(80,30)); 
		
		claim=new JButton("END GAME");
		claim.addActionListener(this);			// IMPORTANT! Without this, clicking the square does nothing.
		claim.setFont(new Font("Comic Sans MS",Font.BOLD,13));
		claim.setBackground(Color.RED);
		claim.setForeground(Color.WHITE);
		claim.setBorder(border1);
		claim.setPreferredSize(new Dimension(50,30)); 
		
		//Close
		Close = new JButton("Close");
		Close.addActionListener(this);			// IMPORTANT! Without this, clicking the square does nothing.
		Close.setFont(new Font("Comic Sans MS",Font.BOLD,13));
		Close.setBackground(new Color(0xFE6100));
		Close.setForeground(Color.WHITE);
		Close.setBorder(border1);
		Close.setPreferredSize(new Dimension(80,30));
		//labels
		instructionLabel.setForeground(Color.WHITE);
		infoLabel.setForeground(Color.WHITE);
		
		PlayerLabel.setForeground(Color.WHITE);
		instructionLabel.setHorizontalAlignment(JLabel.CENTER);
		infoLabel.setHorizontalAlignment(JLabel.CENTER);
		
		PlayerLabel.setHorizontalAlignment(JLabel.CENTER);
		//topPanel
		GridLayout experimentLayout = new GridLayout(0,2,10,7);
		topPanel.setLayout(experimentLayout);
		topPanel.setBackground(Color.GRAY);
		topPanel.add(instructionLabel);
		topPanel.add (topButton);
		topPanel.add(infoLabel);
		topPanel.add(Stop);

		topPanel.add (PlayerLabel);
		topPanel.add (Save);
		topPanel.add(claim);
        
        Border border= new LineBorder(new Color(0x803222),1);
	
		// for the bottom panel:	
		// create the squares and add them to the grid
		gridSquares = new GridSquare[rows][columns];
		gridSquares2 = new GridSquare2[200][200];
		for ( int x = 0; x < columns; x ++)
		{
			for ( int y = 0; y < rows; y ++)
			{
				gridSquares[x][y] = new GridSquare(x, y);
				
				gridSquares[x][y].setSize(20, 20);
				
				gridSquares[x][y].setBackground(Color.GRAY);
				//gridSquares[x][y].setBorder(border);
				gridSquares[x][y].addMouseListener(this);		// AGAIN, don't forget this line!
				
				bottomPanel.add(gridSquares[x][y]);
			}
		} 
		
		for ( int x = 0; x < 200; x ++)
		{
			for ( int y = 0; y < 200; y ++)
			{
				gridSquares2[x][y] = new GridSquare2(x, y);
				
				//gridSquares2[x][y].setSize(20, 20);
				
				gridSquares2[x][y].setBackground(new Color(0xC74F36));
				//gridSquares[x][y].setBorder(border);
				//gridSquares[x][y].addMouseListener(this);		// AGAIN, don't forget this line!
				
				
			}
		}
		
		
		
		cords.put(7, 12);
		cords.put(6, 11);
		cords.put(8, 11);
		cords.put(5, 10);
		cords.put(9, 10);
		cords.put(4, 9);
		cords.put(10, 9);
		cords.put(3, 8);
		cords.put(11, 8);
		cords.put(2, 7);
		cords.put(12, 7);
		
		
		indc=new ArrayList();
		//change colors 
		indc.add(0);
		indc.add(1);
		indc.add(2);
		indc.add(11);
		indc.add(12);
		indc.add(13);
		indc.add(14);
		indc2=new ArrayList();
		
		indc2.add(0);
		indc2.add(1);
		indc2.add(2);
		indc2.add(3);
		indc2.add(10);
		indc2.add(11);
		indc2.add(12);
		indc2.add(13);
		indc2.add(14); 
		
		indc3=new ArrayList();
		
		indc3.add(0);
		indc3.add(1);
		indc3.add(2);
		indc3.add(3);
		indc3.add(4);
		indc3.add(9);
		indc3.add(10);
		indc3.add(11);
		indc3.add(12);
		indc3.add(13);
		indc3.add(14); 
		
		indc4=new ArrayList();
		
		indc4.add(0);
		indc4.add(1);
		indc4.add(2);
		indc4.add(3);
		indc4.add(4);
		indc4.add(5);
		indc4.add(8);
		indc4.add(9);
		indc4.add(10);
		indc4.add(11);
		indc4.add(12);
		indc4.add(13);
		indc4.add(14); 
		
		for ( int z = 0; z < columns; z++)
		{
			for ( int d = 0; d< rows; d++)
			{   
				
				
				if(z==0&&d==7) {
					gridSquares[z][d].setlabel("7");
				}
				else if(z!=0&&z!=13&&z!=14&&d==7) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
					gridSquares [z][d].setLayout(new BorderLayout());
					gridSquares [z][d].add(gridSquares2[5*z+1][5*d+1], BorderLayout.NORTH);
					gridSquares [z][d].add(gridSquares2[5*z+2][5*d+2], BorderLayout.EAST);
					gridSquares [z][d].add(gridSquares2[5*z+3][5*d+3], BorderLayout.SOUTH);
					gridSquares [z][d].add(gridSquares2[5*z+4][5*d+4], BorderLayout.WEST);
					gridSquares [z][d].add(gridSquares2[5*z+5][5*d+5], BorderLayout.CENTER);

				}
				if(z==1&&d==6) {
					gridSquares[z][d].setlabel("6");
				}
				else if(z!=0&&z!=1&&z!=12&&z!=13&&z!=14&&d==6) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
					gridSquares [z][d].setLayout(new BorderLayout());
					gridSquares [z][d].add(gridSquares2[5*z+1][5*d+1], BorderLayout.NORTH);
					gridSquares [z][d].add(gridSquares2[5*z+2][5*d+2], BorderLayout.EAST);
					gridSquares [z][d].add(gridSquares2[5*z+3][5*d+3], BorderLayout.SOUTH);
					gridSquares [z][d].add(gridSquares2[5*z+4][5*d+4], BorderLayout.WEST);
					gridSquares [z][d].add(gridSquares2[5*z+5][5*d+5], BorderLayout.CENTER);
				}
				if(z==1&&d==8) {
					gridSquares[z][d].setlabel("8");
				}
				if(z==8&&d==2) {
					gridSquares[z][d].setlabel("C");
				}
				if(z==9&&d==3) {
					gridSquares[z][d].setlabel("A");
				}
				if(z==10&&d==4) {
					gridSquares[z][d].setlabel("N");
				}
				if(z==11&&d==5) {
					gridSquares[z][d].setlabel("'T");
				}
				if(z==11&&d==9) {
					gridSquares[z][d].setlabel("S");
				}
				if(z==10&&d==10) {
					gridSquares[z][d].setlabel("T");
				}
				if(z==9&&d==11) {
					gridSquares[z][d].setlabel("O");
				}
				if(z==8&&d==12) {
					gridSquares[z][d].setlabel("P");
				}
			
				if(z!=0&&z!=1&&z!=12&&z!=13&&z!=14&&d==8) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
					gridSquares [z][d].setLayout(new BorderLayout());
					gridSquares [z][d].add(gridSquares2[5*z+1][5*d+1], BorderLayout.NORTH);
					gridSquares [z][d].add(gridSquares2[5*z+2][5*d+2], BorderLayout.EAST);
					gridSquares [z][d].add(gridSquares2[5*z+3][5*d+3], BorderLayout.SOUTH);
					gridSquares [z][d].add(gridSquares2[5*z+4][5*d+4], BorderLayout.WEST);
					gridSquares [z][d].add(gridSquares2[5*z+5][5*d+5], BorderLayout.CENTER);
				}
				if(z==2&&d==5) {
					gridSquares[z][d].setlabel("5");
				}
				if((!indc.contains(z))&& d==5) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
					gridSquares [z][d].setLayout(new BorderLayout());
					gridSquares [z][d].add(gridSquares2[5*z+1][5*d+1], BorderLayout.NORTH);
					gridSquares [z][d].add(gridSquares2[5*z+2][5*d+2], BorderLayout.EAST);
					gridSquares [z][d].add(gridSquares2[5*z+3][5*d+3], BorderLayout.SOUTH);
					gridSquares [z][d].add(gridSquares2[5*z+4][5*d+4], BorderLayout.WEST);
					gridSquares [z][d].add(gridSquares2[5*z+5][5*d+5], BorderLayout.CENTER);
				}
				if(z==2&&d==9) {
					gridSquares[z][d].setlabel("9");
				}
				if((!indc.contains(z))&& d==9) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
					gridSquares [z][d].setLayout(new BorderLayout());
					gridSquares [z][d].add(gridSquares2[5*z+1][5*d+1], BorderLayout.NORTH);
					gridSquares [z][d].add(gridSquares2[5*z+2][5*d+2], BorderLayout.EAST);
					gridSquares [z][d].add(gridSquares2[5*z+3][5*d+3], BorderLayout.SOUTH);
					gridSquares [z][d].add(gridSquares2[5*z+4][5*d+4], BorderLayout.WEST);
					gridSquares [z][d].add(gridSquares2[5*z+5][5*d+5], BorderLayout.CENTER);
				}
				if(z==3&&d==4) {
					gridSquares[z][d].setlabel("4");
				}
				if((!indc2.contains(z))&&d==4) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
					gridSquares [z][d].setLayout(new BorderLayout());
					gridSquares [z][d].add(gridSquares2[5*z+1][5*d+1], BorderLayout.NORTH);
					gridSquares [z][d].add(gridSquares2[5*z+2][5*d+2], BorderLayout.EAST);
					gridSquares [z][d].add(gridSquares2[5*z+3][5*d+3], BorderLayout.SOUTH);
					gridSquares [z][d].add(gridSquares2[5*z+4][5*d+4], BorderLayout.WEST);
					gridSquares [z][d].add(gridSquares2[5*z+5][5*d+5], BorderLayout.CENTER);
				}
				if(z==3&&d==10) {
					gridSquares[z][d].setlabel("10");
				}
				if((!indc2.contains(z))&&d==10) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
					gridSquares [z][d].setLayout(new BorderLayout());
					gridSquares [z][d].add(gridSquares2[5*z+1][5*d+1], BorderLayout.NORTH);
					gridSquares [z][d].add(gridSquares2[5*z+2][5*d+2], BorderLayout.EAST);
					gridSquares [z][d].add(gridSquares2[5*z+3][5*d+3], BorderLayout.SOUTH);
					gridSquares [z][d].add(gridSquares2[5*z+4][5*d+4], BorderLayout.WEST);
					gridSquares [z][d].add(gridSquares2[5*z+5][5*d+5], BorderLayout.CENTER);
				}
				if(z==4&&d==3) {
					gridSquares[z][d].setlabel("3");
				}
				if((!indc3.contains(z))&&d==3) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
					gridSquares [z][d].setLayout(new BorderLayout());
					gridSquares [z][d].add(gridSquares2[5*z+1][5*d+1], BorderLayout.NORTH);
					gridSquares [z][d].add(gridSquares2[5*z+2][5*d+2], BorderLayout.EAST);
					gridSquares [z][d].add(gridSquares2[5*z+3][5*d+3], BorderLayout.SOUTH);
					gridSquares [z][d].add(gridSquares2[5*z+4][5*d+4], BorderLayout.WEST);
					gridSquares [z][d].add(gridSquares2[5*z+5][5*d+5], BorderLayout.CENTER);
				}
				if(z==4&&d==11) {
					gridSquares[z][d].setlabel("11");
				}
				if((!indc3.contains(z))&&d==11) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
					gridSquares [z][d].setLayout(new BorderLayout());
					gridSquares [z][d].add(gridSquares2[5*z+1][5*d+1], BorderLayout.NORTH);
					gridSquares [z][d].add(gridSquares2[5*z+2][5*d+2], BorderLayout.EAST);
					gridSquares [z][d].add(gridSquares2[5*z+3][5*d+3], BorderLayout.SOUTH);
					gridSquares [z][d].add(gridSquares2[5*z+4][5*d+4], BorderLayout.WEST);
					gridSquares [z][d].add(gridSquares2[5*z+5][5*d+5], BorderLayout.CENTER);
				}
				if(z==5&&d==2) {
					gridSquares[z][d].setlabel("2");
				}
				if((!indc4.contains(z))&&d==2) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares [z][d].setLayout(new BorderLayout());
					gridSquares[z][d].setBorder(border);
					gridSquares [z][d].add(gridSquares2[5*z+1][5*d+1], BorderLayout.NORTH);
					gridSquares [z][d].add(gridSquares2[5*z+2][5*d+2], BorderLayout.EAST);
					gridSquares [z][d].add(gridSquares2[5*z+3][5*d+3], BorderLayout.SOUTH);
					gridSquares [z][d].add(gridSquares2[5*z+4][5*d+4], BorderLayout.WEST);
					gridSquares [z][d].add(gridSquares2[5*z+5][5*d+5], BorderLayout.CENTER);
					
				}
				if(z==5&&d==12) {
					gridSquares[z][d].setlabel("12");
				}
				if((!indc4.contains(z))&&d==12) {
					gridSquares[z][d].setBackground(new Color(0xC74F36));
					gridSquares[z][d].setBorder(border);
					gridSquares [z][d].setLayout(new BorderLayout());
					gridSquares [z][d].add(gridSquares2[5*z+1][5*d+1], BorderLayout.NORTH);
					gridSquares [z][d].add(gridSquares2[5*z+2][5*d+2], BorderLayout.EAST);
					gridSquares [z][d].add(gridSquares2[5*z+3][5*d+3], BorderLayout.SOUTH);
					gridSquares [z][d].add(gridSquares2[5*z+4][5*d+4], BorderLayout.WEST);
					gridSquares [z][d].add(gridSquares2[5*z+5][5*d+5], BorderLayout.CENTER);
				}

				
			}
		}
		
		
		// now add the top and bottom panels to the main frame
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(topPanel, BorderLayout.NORTH);
		getContentPane().add(bottomPanel, BorderLayout.CENTER);		// needs to be center or will draw too small
		getContentPane().add(anotherPanel, BorderLayout.SOUTH);
		// housekeeping : behaviour
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		setResizable(true); 
		setVisible(true);
	}
	
	
	/*
	 *  handles actions performed in the gui
	 *  this method must be present to correctly implement the ActionListener interface
	 */
	public void actionPerformed(ActionEvent aevt)
	{ 
		// get the object that was selected in the gui
		Object selected = aevt.getSource();
		Border border= new LineBorder(new Color(0x803222),1);
		
		
		
		if(selected.equals(Roll)) {
			
			
			Roll diceRoll1= new Roll();
			diceRoll1.MakeRoll();
			Comb1.setText(diceRoll1.getComb1());
			Comb2.setText(diceRoll1.getComb2());
			Comb3.setText(diceRoll1.getComb3());
		
			
						
			RollInfo.setText("You rolled "+diceRoll1.getDice1()+", "+diceRoll1.getDice2()+", "+diceRoll1.getDice3()+", "+diceRoll1.getDice4()+" . pick one combination ");
			RollInfo.setForeground(Color.white);
			RollInfo.setFont(new Font("Comic Sans MS",Font.BOLD,13));
			anotherPanel.add(RollInfo);
			anotherPanel.add(Comb1);
			anotherPanel.add(Comb2);
			anotherPanel.add(Comb3);
			anotherPanel.add(Bust);
			Comb1.setVisible(true);
			Comb2.setVisible(true);
			Comb3.setVisible(true);
			Stop.setVisible(false);
			Bust.setVisible(false);
			getContentPane().add(anotherPanel, BorderLayout.SOUTH);
			setVisible(true); 
			
			
			
		}		
		else if ( selected.equals(Stop) )
		{	//player 1 turn
			if(playerID==1) {
				white_count=0;
			for ( int z = 0; z < columns; z++)
			{
				for ( int d = 0; d< rows; d++)
				{	
					if(gridSquares2[5*z+1][5*d+1].getBackground().equals(new Color(0xD81B60))){
						gridSquares2[5*z+1][5*d+1].setBackground(new Color(0xC74F36));
					}
					if(gridSquares2[5*z+5][5*d+5].getBackground().equals(Color.WHITE)) {
						gridSquares2[5*z+1][5*d+1].setBackground(new Color(0xD81B60));
						gridSquares2[5*z+5][5*d+5].setBackground(new Color(0xC74F36));
						
					}
					
					
				}
			}
			}
			
			//player 2 turn
			else if(playerID==2) {
				white_count=0;
				for ( int z = 0; z < columns; z++)
				{
					for ( int d = 0; d< rows; d++)
					{	
						//new Color(0x1E88E5)
						
						if(gridSquares2[5*z+2][5*d+2].getBackground().equals(new Color(0x1E88E5))){
							gridSquares2[5*z+2][5*d+2].setBackground(new Color(0xC74F36));
						}
						if(gridSquares2[5*z+5][5*d+5].getBackground().equals(Color.WHITE)) {
							gridSquares2[5*z+2][5*d+2].setBackground(new Color(0x1E88E5));
							gridSquares2[5*z+5][5*d+5].setBackground(new Color(0xC74F36));
							
						}
						
					}
				}
			}
			//player 3 turn
			else if(playerID==3) {
				white_count=0;
				for ( int z = 0; z < columns; z++)
				{
					for ( int d = 0; d< rows; d++)
					{	
						//new Color(0xFFC107)
						if(gridSquares2[5*z+3][5*d+3].getBackground().equals(new Color(0xFFC107))){
							gridSquares2[5*z+3][5*d+3].setBackground(new Color(0xC74F36));
						}
						if(gridSquares2[5*z+5][5*d+5].getBackground().equals(Color.WHITE)) {
							gridSquares2[5*z+3][5*d+3].setBackground(new Color(0xFFC107));
							gridSquares2[5*z+5][5*d+5].setBackground(new Color(0xC74F36));
							
						}
					}
				}
			}
			//player 4 turn
			else if(playerID==4) {
				white_count=0;
				for ( int z = 0; z < columns; z++)
				{
					for ( int d = 0; d< rows; d++)
					{	
						//new Color(0x0FFFD7)
						if(gridSquares2[5*z+4][5*d+4].getBackground().equals(new Color(0x0FFFD7))){
							gridSquares2[5*z+4][5*d+4].setBackground(new Color(0xC74F36));
						}
						if(gridSquares2[5*z+5][5*d+5].getBackground().equals(Color.WHITE)) {
							gridSquares2[5*z+4][5*d+4].setBackground(new Color(0x0FFFD7));
							gridSquares2[5*z+5][5*d+5].setBackground(new Color(0xC74F36));
							
						}
					}
				}
			}
			
			
			if(playerID<TotalPlayers){
				playerID++;
			}
			else {
				playerID=1;
			}
			PlayerLabel.setText("Player "+playerID+" make a roll");
			PlayerLabel.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		}
		else if(selected.equals(Comb1)) {
			Comb1.setVisible(false);
			Comb2.setVisible(false);
			Comb3.setVisible(false);
			RollInfo.setText("You selected "+Comb1.getText()+" . Move cubes in valid columns or");
			Stop.setVisible(true);
			Bust.setVisible(true);
			}
			
		else if(selected.equals(Comb2)) {
			Comb1.setVisible(false);
			Comb2.setVisible(false);
			Comb3.setVisible(false);
			RollInfo.setText("You selected "+Comb2.getText()+" . Move cubes in those columns or");
			Stop.setVisible(true);
			Bust.setVisible(true);
		}
		else if(selected.equals(Comb3)) {
			Comb1.setVisible(false);
			Comb2.setVisible(false);
			Comb3.setVisible(false);
			RollInfo.setText("You selected "+Comb3.getText()+" . Move cubes in those columns or");
			Stop.setVisible(true);
			Bust.setVisible(true);
		}
			
			
		
		else if(selected.equals(Bust)){
			for ( int x = 0; x < columns; x++)
			{
				for ( int y = 0; y < rows; y++)
				{
					if(gridSquares2 [5*x+5][5*y+5].getBackground().equals(Color.WHITE)){
						gridSquares2 [5*x+5][5*y+5].setBackground(new Color(0xC74F36));
					
					}
				}
			}
			if(playerID<TotalPlayers){
				playerID++;
			}
			else {
				playerID=1;
			}
			PlayerLabel.setText("Player "+playerID+" make a roll");
			PlayerLabel.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		}
		
		else if(selected.equals(claim)){
			
			this.setVisible(false);
		}
		else if(selected.equals(Save)) {
			//player.setWindowDemo(player.getWindowDemo());
		}
		// if resetting the squares' colours is requested then do so
		else if ( selected.equals(topButton) )
		{
			playerID=1;
			ClaimCount1=0;
			ClaimCount2=0;
			ClaimCount3=0;
			ClaimCount4=0;
			white_count=0;
			for ( int x = 0; x < columns; x++)
			{
				for ( int y = 0; y < rows; y++)
				{
					
					gridSquares2 [5*x+5][5*y+5].setBackground(new Color(0xC74F36));
					gridSquares2 [5*x+1][5*y+1].setBackground(new Color(0xC74F36));
					gridSquares2 [5*x+2][5*y+2].setBackground(new Color(0xC74F36));
					gridSquares2 [5*x+3][5*y+3].setBackground(new Color(0xC74F36));
					gridSquares2 [5*x+4][5*y+4].setBackground(new Color(0xC74F36));
					
				}
			}
		}
	
	}
	public void conquer_row() {
		if (gridSquares2[1][7].getBackground()==Color.WHITE) {
			for ( int z = 0; z < columns; z++)
			{
				for ( int d = 0; d< rows; d++)
				{ 
					if(z!=0&&z!=13&&z!=14&&d==7) {
						gridSquares[z][d].setBackground(Color.BLUE);
				}}}
		}
	}
	public boolean check_conquer() {
		return false;
	}

	// Mouse Listener events
	public void mouseClicked(MouseEvent mevt)
	{
		// get the object that was selected in the gui
		Object selected = mevt.getSource();
		
		/*
		 * I'm using instanceof here so that I can easily cover the selection of any of the gridsquares
		 * with just one piece of code.
		 * In a real system you'll probably have one piece of action code per selectable item.
		 * Later in the course we'll see that the Command Holder pattern is a much smarter way to handle actions.
		 */
		
		// if a gridsquare is selected then switch its color
		if (prevsquare!= null) {
			prevx = prevsquare.getXcoord();
            prevy = prevsquare.getYcoord();
			
				
		}
		if (selected instanceof GridSquare)
		{	
			
            GridSquare square = (GridSquare) selected;
            
			if(winner!=1) {
			for ( int x = 0; x < columns; x++)
			{
				for ( int y = 0; y < rows; y++)
				{
					
					if(gridSquares2 [5*x+5][5*y+5].getBackground().equals(Color.WHITE)){
						visitedx.add(x);
						visitedy.add(y);
					if(y==square.getYcoord()){
						white_count--;
						gridSquares2 [5*x+5][5*y+5].setBackground(new Color(0xC74F36));
						
						

					}
					
					}
					
					
					
				}
			} 
            x = square.getXcoord();
            y = square.getYcoord();
            
            if(square.getBackground().equals(Color.GRAY)&&(square.getXcoord()==0 && square.getYcoord()==7)||
            		(square.getXcoord()==1 && square.getYcoord()==8)||(square.getXcoord()==1 && square.getYcoord()==6)||
						(square.getXcoord()==2 && square.getYcoord()==5)||(square.getXcoord()==2 && square.getYcoord()==9)||
						(square.getXcoord()==3 && square.getYcoord()==4)|| (square.getXcoord()==3 && square.getYcoord()==10)||
						(square.getXcoord()==4 && square.getYcoord()==3)||(square.getXcoord()==5 && square.getYcoord()==2)||
						(square.getXcoord()==4 && square.getYcoord()==11)|| (square.getXcoord()==5 && square.getYcoord()==12)){
				if(playerID==1){
					
					ClaimCount1++;
					if(ClaimCount1<=3) {
						gridSquares [x][y].setBackground(new Color(0xD81B60)); 
					}
					if(ClaimCount1==3){
						PlayerLabel.setText("Congratulations Player 1, You won!!!!");
						PlayerLabel.setFont(new Font("Comic Sans MS",Font.BOLD,22));
						winner=1;
						winner(1);
					}
					for ( int x = 0; x < columns; x++)
					{
						for ( int y = 0; y < rows; y++)
						{
							
							
							if(y==square.getYcoord()){
								gridSquares2 [5*x+5][5*y+5].setBackground(new Color(0xC74F36));
								gridSquares2 [5*x+2][5*y+2].setBackground(new Color(0xC74F36));
								gridSquares2 [5*x+3][5*y+3].setBackground(new Color(0xC74F36));
								gridSquares2 [5*x+4][5*y+4].setBackground(new Color(0xC74F36));

								
							}	
						}
					}
				}
				if(playerID==2){
					ClaimCount2++;
					if(ClaimCount2<=3) {
						gridSquares [x][y].setBackground(new Color(0x1E88E5));
					}
					
					if(ClaimCount2==3){
						PlayerLabel.setText("Congratulations Player 2, You won!!!!");
						PlayerLabel.setFont(new Font("Comic Sans MS",Font.BOLD,22));
						winner=1;
						winner(2);
					}
					for ( int x = 0; x < columns; x++)
					{
						for ( int y = 0; y < rows; y++)
						{
							
							
							if(y==square.getYcoord()){
								gridSquares2 [5*x+5][5*y+5].setBackground(new Color(0xC74F36));
								gridSquares2 [5*x+1][5*y+1].setBackground(new Color(0xC74F36));
								gridSquares2 [5*x+3][5*y+3].setBackground(new Color(0xC74F36));
								gridSquares2 [5*x+4][5*y+4].setBackground(new Color(0xC74F36));

								
							}	
						}
					}
				}
				if(playerID==3){
					ClaimCount3++;
					if(ClaimCount3<=3) {
						gridSquares [x][y].setBackground(new Color(0xFFC107));
					}
					if(ClaimCount3==3){
						PlayerLabel.setText("Congratulations Player 3, You won!!!!");
						PlayerLabel.setFont(new Font("Comic Sans MS",Font.BOLD,22));
						winner=1;
						winner(3);
					}
					for ( int x = 0; x < columns; x++)
					{
						for ( int y = 0; y < rows; y++)
						{
							
							
							if(y==square.getYcoord()){
								gridSquares2 [5*x+5][5*y+5].setBackground(new Color(0xC74F36));
								gridSquares2 [5*x+2][5*y+2].setBackground(new Color(0xC74F36));
								gridSquares2 [5*x+1][5*y+1].setBackground(new Color(0xC74F36));
								gridSquares2 [5*x+4][5*y+4].setBackground(new Color(0xC74F36));

								
							}	
						}
					}
				}
				if(playerID==4){
					ClaimCount4++;
					if(ClaimCount4<=3) {
						gridSquares [x][y].setBackground(new Color(0x0FFFD7));
					}
					if(ClaimCount4==3){
						PlayerLabel.setText("Congratulations Player 4, You won!!!!");
						PlayerLabel.setFont(new Font("Comic Sans MS",Font.BOLD,22));
						winner=1;
						winner(4);
					}
					for ( int x = 0; x < columns; x++)
					{
						for ( int y = 0; y < rows; y++)
						{
							
							
							if(y==square.getYcoord()){
								gridSquares2 [5*x+5][5*y+5].setBackground(new Color(0xC74F36));
								gridSquares2 [5*x+2][5*y+2].setBackground(new Color(0xC74F36));
								gridSquares2 [5*x+3][5*y+3].setBackground(new Color(0xC74F36));
								gridSquares2 [5*x+1][5*y+1].setBackground(new Color(0xC74F36));

								
							}	
						}
					}
				}
			}
            
			//STACKS
			//if(!square.getBackground().equals(new Color(0xC74F36))) {
				//gridSquares [x][y].setLayout(new BorderLayout());
				//gridSquares [x][y].add(gridSquares2[2*x+1][2*y+1], BorderLayout.NORTH);
				//gridSquares [x][y].add(gridSquares2[2*x+2][2*y+2], BorderLayout.EAST);
				//gridSquares [x][y].add(gridSquares2[2*x+3][2*y+3], BorderLayout.SOUTH);
				//gridSquares [x][y].add(gridSquares2[2*x+4][2*y+4], BorderLayout.WEST);
				//gridSquares [x][y].add(gridSquares2[2*x+5][2*y+5], BorderLayout.CENTER);
				
				//gridSquares2[2*x+5][2*y+5].setBackground(Color.white);
				
				
			
			if(white_count>=3) {
				int x=5;
			}
			else {
				gridSquares2[5*x+5][5*y+5].setBackground(Color.white);
				white_count++;
			}
			
		
            
            
            prevsquare = square;
            gridSquares[x][y].revalidate();
            gridSquares[x][y].repaint();
		}}	
		
	}
	public void winner(int color) {
			for ( int z = 0; z < columns; z++)
			{
				for ( int d = 0; d< rows; d++)
				{ 
					if(color==1) {
						gridSquares[z][d].setBackground(new Color(0xD81B60));
					}
					else if(color==2) {
						gridSquares[z][d].setBackground(new Color(0x1E88E5));
					}
					else if(color==3) {
						gridSquares[z][d].setBackground(new Color(0xFFC107));
					}
					else if(color==4) {
						gridSquares[z][d].setBackground(new Color(0x0FFFD7));
					}
				} 
			}
	}
	
	    
	
	// not used but must be present to fulfil MouseListener contract
	public void mouseEntered(MouseEvent arg0){}
	public void mouseExited(MouseEvent arg0) {}
	public void mousePressed(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}
	
	}

	 
