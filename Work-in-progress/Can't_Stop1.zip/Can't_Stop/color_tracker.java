

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.JOptionPane;

public class color_tracker extends JFrame implements ActionListener, MouseListener{
	String Color_mode=new String();
	String Color_code=new String();
	String Color_sat=new String();
	String color_lightness=new String();
	JLabel header=new JLabel();
	JLabel med_text=new JLabel();
	JLabel med_text1=new JLabel();
	JLabel bot_text=new JLabel();
	JLabel bot_text1=new JLabel();
	JLabel bot_text2=new JLabel();
	JLabel bot_text3=new JLabel();
	JButton button= new JButton();
	JButton button1=new JButton();
	public color_tracker() {
		int x=5;
	}
	public void make_frame() {
		this.setSize(600,700);
		this.setTitle("Play Game");
		this.getContentPane().setBackground(new Color(0x16A4DD));
		this.setLayout(new BorderLayout());
		this.setVisible(true); 
		header.setText(" Can't");
		header.setFont(new Font("Comic Sans MS",Font.BOLD,46)); 
		header.setForeground(Color.white); 
		
		Border border= new LineBorder(Color.BLACK,6);
		
		//button1.setAlignmentY(Component.TOP_ALIGNMENT);
		//button4.setPreferredSize(new Dimension(100,50));
	
		
		
		JPanel topPanel= new JPanel();
		topPanel.setLayout(new BoxLayout(topPanel,BoxLayout.Y_AXIS));
		topPanel.add(Box.createVerticalStrut(30));
		topPanel.setBackground(new Color(0x16A4DD));
		header.setAlignmentX(Component.CENTER_ALIGNMENT);
		topPanel.add(header); 
		med_text.setText("Stop");
		med_text.setFont(new Font("Comic Sans MS",Font.BOLD,46)); 
		med_text.setAlignmentX(Component.CENTER_ALIGNMENT);
		med_text.setForeground(Color.white); 
		
		med_text1.setText("Color Details:");
		med_text1.setFont(new Font("Comic Sans MS",Font.BOLD,36)); 
		med_text1.setAlignmentX(Component.CENTER_ALIGNMENT);
		med_text1.setForeground(Color.BLACK);
		
		bot_text.setText("Color Mode: "+get_color());
		bot_text.setFont(new Font("Comic Sans MS",Font.BOLD,30)); 
		bot_text.setAlignmentX(Component.CENTER_ALIGNMENT);
		bot_text.setForeground(Color.BLACK); 
		
		bot_text1.setText("Color Code: "+get_colorCODE());
		bot_text1.setFont(new Font("Comic Sans MS",Font.BOLD,30)); 
		bot_text1.setAlignmentX(Component.CENTER_ALIGNMENT);
		bot_text1.setForeground(Color.BLACK);
		
		bot_text2.setText("Color Sat: "+get_colorSAT());
		bot_text2.setFont(new Font("Comic Sans MS",Font.BOLD,30)); 
		bot_text2.setAlignmentX(Component.CENTER_ALIGNMENT);
		bot_text2.setForeground(Color.BLACK); 
		
		bot_text3.setText("Color Lightness: "+get_colorLIGHT());
		bot_text3.setFont(new Font("Comic Sans MS",Font.BOLD,28)); 
		bot_text3.setAlignmentX(Component.CENTER_ALIGNMENT);
		bot_text3.setForeground(Color.BLACK); 
		
		
		
		topPanel.add(med_text);
		topPanel.add(med_text1);
		topPanel.add(bot_text);
		topPanel.add(bot_text1);
		topPanel.add(bot_text2);
		topPanel.add(bot_text3);
		topPanel.setBorder(BorderFactory.createEmptyBorder(20,20,40,20));
		
		
		//button.setBounds(195,170,00,50);
		button.setText("Confirm Color"); 
		button.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button.setBackground(Color.white); 
		button.setBorder(border);
		button.setAlignmentY(Component.TOP_ALIGNMENT);
		button.setPreferredSize(new Dimension(200,50)); 
		button.addMouseListener(this); 
		
		button1.setText("Back"); 
		button1.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button1.setBackground(Color.white); 
		button1.setBorder(border);
		//button1.setAlignmentY(Component.TOP_ALIGNMENT);
		button1.setPreferredSize(new Dimension(200,50)); 
		button1.addMouseListener(this);
		
	
		JPanel buttonPanel= new JPanel(new FlowLayout(FlowLayout.CENTER));
		buttonPanel.setBackground(new Color(0x16A4DD)); 
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));  
		
		JPanel panel1= new JPanel();
		panel1.setBackground(new Color(0x16A4DD));
		panel1.setPreferredSize(new Dimension(50,50)); 
		panel1.add(button); 

		
		JPanel panel2= new JPanel();
		panel2.setBackground(new Color(0x16A4DD));
		panel2.setPreferredSize(new Dimension(50,50)); 
		panel2.add(button1); 
		
		
		buttonPanel.add(panel1); 
		buttonPanel.add(panel2); 
		
		
		this.add(topPanel, BorderLayout.NORTH); 
		this.add(buttonPanel, BorderLayout.CENTER);
		//this.add(buttonPanel1,BorderLayout.CENTER);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	
	public void set_color(String clr) {
		this.Color_mode=clr;
	
	}
	public String get_color() {
		return this.Color_mode;
	}
	public void set_colorSAT(String clr) {
		this.Color_sat=clr;
	
	}
	public String get_colorSAT() {
		return this.Color_sat;
	}
	public void set_colorLIGHT(String clr) {
		this.color_lightness=clr;
	
	}
	public String get_colorLIGHT() {
		return this.color_lightness;
	}
	public void set_colorCODE(String code) {
		this.Color_code=code;
	
	}
	public String get_colorCODE() {
		return this.Color_code;
	}




	public void mouseClicked(MouseEvent mevt)
	{
		// get the object that was selected in the 
		Object selected = mevt.getSource();
		if(selected.equals(button)) {
			difficulty demo1=new difficulty();
			demo1.set_color(get_color());
			JOptionPane.showMessageDialog(null,"Color setting confirmed.");
			
			
		}
		if(selected.equals(button1)) {
			//this.setVisible(false);
			//this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			difficulty demo1=new difficulty();
			demo1.set_color(get_color());
			color_settings demo= new color_settings();
			this.setVisible(false);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		}
		
		//this.setVisible(false);
		
	}
	
	public void mouseEntered(MouseEvent arg0){
		Object selected = arg0.getSource();
		if(selected.equals(button)) {
			button.setBackground(Color.gray);
		}
		if(selected.equals(button1)) {
			button1.setBackground(Color.gray);
		}
		if(selected.equals(button1)) {
			button1.setBackground(Color.gray);
		}
	}
	public void mouseExited(MouseEvent arg0) {
		//button.setBounds(195,170,200,50);
		Object selected = arg0.getSource();
		if(selected.equals(button)) {
			button.setBackground(Color.WHITE);
		}
		if(selected.equals(button1)) {
			button1.setBackground(Color.WHITE);
		}
		
		
	}
	public void mousePressed(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}

