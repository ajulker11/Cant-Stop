import java.util.Random;
import java.util.ArrayList;
public class Roll {
	private int dice1;
	private int dice2;
	private int dice3;
	private int dice4;
	private int pair1;
	private int pair2;
	private int pair3;
	private int pair4;
	private int pair5;
	private int pair6;
	private String comb1;
	private String comb2;
	private String comb3;
	
	public Roll() {
	dice1=0;
	dice2=0;
	dice3=0;
	dice4=0;
	pair1=0;
	pair2=0;
	pair3=0;
	

	
	
	}
	public void MakeRoll() {
		Random r = new Random();
		ArrayList<Integer> results = new ArrayList<Integer>();
		int result =0;
		for(int i=0;i<4;i++) {
		
		result = r.nextInt(1, 7);
		//System.out.println("you rolled a res"+result);
		results.add(result);		
		}
		//System.out.println(results.toString());
		this.setDice1(results.get(0));
		this.setDice2(results.get(1));
		this.setDice3(results.get(2));
		this.setDice4(results.get(3));
		
		
		this.setPair1(dice1+dice2);
		this.setPair2(dice3+dice4);
		this.setPair3(dice1+dice3);
		this.setPair4(dice2+dice4);
		this.setPair5(dice1+dice4);
		this.setPair6(dice2+dice3);
		
		this.setComb1(Integer.toString(pair1)+" and "+Integer.toString(pair2));
		this.setComb2(Integer.toString(pair3)+" and "+Integer.toString(pair4));
		this.setComb3(Integer.toString(pair5)+" and "+Integer.toString(pair6));
		
		//System.out.println("you rolled a"+result);
		
		
		
		
	}
	public int getPair3() {
		return pair3;
	}

	public void setPair3(int pair3) {
		this.pair3 = pair3;
	}

	public int getPair2() {
		return pair2;
	}

	public void setPair2(int pair2) {
		this.pair2 = pair2;
	}

	public int getPair1() {
		return pair1;
	}

	public void setPair1(int pair1) {
		this.pair1 = pair1;
	}
	/*
	public static void main(String[] args)
	{
		Roll a = new Roll();
		a.MakeRoll();
		int num = a.getPair1();
		int num1 = a.getPair2();
		int num2 = a.getPair3();
		int num3 = a.getPair4();
		String combn1 = a.getComb1();
		String combn2 = a.getComb2();
		String combn3 = a.getComb3();
		System.out.println("you d1 a "+num);
		System.out.println("you d2 a "+num1);
		System.out.println("you d3 a "+num2);
		System.out.println("you d4 a "+num3);
		System.out.println(combn1);
		System.out.println(combn2);
		System.out.println(combn3);
	}*/
	public int getDice4() {
		return dice4;
	}
	public void setDice4(int dice4) {
		this.dice4 = dice4;
	}
	public int getDice3() {
		return dice3;
	}
	public void setDice3(int dice3) {
		this.dice3 = dice3;
	}
	public int getDice2() {
		return dice2;
	}
	public void setDice2(int dice2) {
		this.dice2 = dice2;
	}
	public int getDice1() {
		return dice1;
	}
	public void setDice1(int dice1) {
		this.dice1 = dice1;
	}
	public int getPair4() {
		return pair4;
	}
	public void setPair4(int pair4){
		this.pair4 = pair4;
	}
	public int getPair6() {
		return pair6;
	}
	public void setPair6(int pair6) {
		this.pair6 = pair6;
	}
	public int getPair5() {
		return pair5;
	}
	public void setPair5(int pair5) {
		this.pair5 = pair5;
	}
	public String getComb1() {
		return comb1;
	}
	public void setComb1(String comb1) {
		this.comb1 = comb1;
	}
	public String getComb2() {
		return comb2;
	}
	public void setComb2(String comb2) {
		this.comb2 = comb2;
	}
	public String getComb3() {
		return comb3;
	}
	public void setComb3(String comb3) {
		this.comb3 = comb3;
	}
}
