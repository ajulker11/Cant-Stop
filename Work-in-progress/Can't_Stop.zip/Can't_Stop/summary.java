

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class summary extends JFrame implements ActionListener, MouseListener{
	JLabel header= new JLabel();
	JLabel med_text= new JLabel();
	JLabel bot_text= new JLabel();
	JLabel bot_text1= new JLabel();
	JLabel bot_text2= new JLabel();
	JButton button = new JButton();
	JButton button1 = new JButton();
	String numPlayers=new String();
	String diff=new String();
	String Color_mode=new String("Normal");
	Player player = Player.PlayerSingleton(); 
	public summary(){
		int x=1;
	} 
	
	public void makeFrame() {
		this.setSize(600,700);
		this.setTitle("Play Game");
		this.getContentPane().setBackground(new Color(0x16A4DD));
		this.setLayout(new BorderLayout());
		this.setVisible(true); 
		header.setText(" Can't");
		header.setFont(new Font("Comic Sans MS",Font.BOLD,46)); 
		header.setForeground(Color.white); 
		
		Border border= new LineBorder(Color.BLACK,6);
		
		//button1.setAlignmentY(Component.TOP_ALIGNMENT);
		//button4.setPreferredSize(new Dimension(100,50));
	
		
		
		JPanel topPanel= new JPanel();
		topPanel.setLayout(new BoxLayout(topPanel,BoxLayout.Y_AXIS));
		topPanel.add(Box.createVerticalStrut(30));
		topPanel.setBackground(new Color(0x16A4DD));
		header.setAlignmentX(Component.CENTER_ALIGNMENT);
		topPanel.add(header); 
		med_text.setText("Stop");
		med_text.setFont(new Font("Comic Sans MS",Font.BOLD,46)); 
		med_text.setAlignmentX(Component.CENTER_ALIGNMENT);
		med_text.setForeground(Color.white); 
		
		bot_text.setText("Number of players: "+get_numPlayers());
		bot_text.setFont(new Font("Comic Sans MS",Font.BOLD,36)); 
		bot_text.setAlignmentX(Component.CENTER_ALIGNMENT);
		bot_text.setForeground(Color.BLACK); 
		
		bot_text1.setText("Level of Difficulty: "+get_diffLevel());
		bot_text1.setFont(new Font("Comic Sans MS",Font.BOLD,36)); 
		bot_text1.setAlignmentX(Component.CENTER_ALIGNMENT);
		bot_text1.setForeground(Color.BLACK);
		
		bot_text2.setText("Color Mode: "+get_color());
		bot_text2.setFont(new Font("Comic Sans MS",Font.BOLD,36)); 
		bot_text2.setAlignmentX(Component.CENTER_ALIGNMENT);
		bot_text2.setForeground(Color.BLACK);
		
		
		topPanel.add(med_text);
		topPanel.add(bot_text);
		topPanel.add(bot_text1);
		topPanel.add(bot_text2);
		topPanel.setBorder(BorderFactory.createEmptyBorder(20,20,40,20));
		
		
		//button.setBounds(195,170,00,50);
		button.setText("Play Game"); 
		button.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button.setBackground(Color.white); 
		button.setBorder(border);
		button.setAlignmentY(Component.TOP_ALIGNMENT);
		button.setPreferredSize(new Dimension(200,50)); 
		button.addMouseListener(this); 
		
		button1.setText("Back"); 
		button1.setFont(new Font("Comic Sans MS",Font.BOLD,26)); 
		button1.setBackground(Color.white); 
		button1.setBorder(border);
		//button1.setAlignmentY(Component.TOP_ALIGNMENT);
		button1.setPreferredSize(new Dimension(200,50)); 
		button1.addMouseListener(this);
		
	
		JPanel buttonPanel= new JPanel(new FlowLayout(FlowLayout.CENTER));
		buttonPanel.setBackground(new Color(0x16A4DD)); 
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));  
		
		JPanel panel1= new JPanel();
		panel1.setBackground(new Color(0x16A4DD));
		panel1.setPreferredSize(new Dimension(50,50)); 
		panel1.add(button); 

		
		JPanel panel2= new JPanel();
		panel2.setBackground(new Color(0x16A4DD));
		panel2.setPreferredSize(new Dimension(50,50)); 
		panel2.add(button1); 
		
		
		buttonPanel.add(panel1); 
		buttonPanel.add(panel2); 
		
		int number = Integer.parseInt(get_numPlayers());
		player.setDifficulty(get_diffLevel());
		player.setNumPlayers(number);
		
		this.add(topPanel, BorderLayout.NORTH); 
		this.add(buttonPanel, BorderLayout.CENTER);
		//this.add(buttonPanel1,BorderLayout.CENTER);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	
	public void set_color(String clr) {
		this.Color_mode=clr;
	
	}
	public String get_color() {
		return this.Color_mode;
	}
	
	public void actionPerformed(ActionEvent aevt) {
		/**Object Selected = aevt.getSource();
		if(Selected.equals(button)) {
			WindowDemo demo = new WindowDemo(15, 15);
			this.setVisible(false);
		}
		if(Selected.equals(button2)) {
			WindowDemo demo = new WindowDemo(15, 15);
			this.setVisible(false);
		}
		
		// if resetting the squares' colours is requested then do so
		**/
	}
	public void set_numPlayers(String num) {
		this.numPlayers=num;
	}
	public String get_numPlayers() {
		return this.numPlayers;
	}
	
	public void set_diff(String lvl) {
		this.diff=lvl;
	}
	public String get_diffLevel() {
		return this.diff;
	}
	
	public void mouseClicked(MouseEvent mevt)
	{
		// get the object that was selected in the 
		Object selected = mevt.getSource();
		if(selected.equals(button)) {
			WindowDemo windowDemo=new WindowDemo(15,15);
			player.setWindowDemo(windowDemo);
			this.setVisible(false); 
			
		}
		if(selected.equals(button1)) {
			//this.setVisible(false);
			//this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			difficulty demo= new difficulty();
			demo.makeFrame();
			this.setVisible(false);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		}
		
		//this.setVisible(false);
		
	}
	
	public void mouseEntered(MouseEvent arg0){
		Object selected = arg0.getSource();
		if(selected.equals(button)) {
			button.setBackground(Color.gray);
		}
		if(selected.equals(button1)) {
			button1.setBackground(Color.gray);
		}
		if(selected.equals(button1)) {
			button1.setBackground(Color.gray);
		}
	}
	public void mouseExited(MouseEvent arg0) {
		//button.setBounds(195,170,200,50);
		Object selected = arg0.getSource();
		if(selected.equals(button)) {
			button.setBackground(Color.WHITE);
		}
		if(selected.equals(button1)) {
			button1.setBackground(Color.WHITE);
		}
		
		
	}
	public void mousePressed(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}
	
}
