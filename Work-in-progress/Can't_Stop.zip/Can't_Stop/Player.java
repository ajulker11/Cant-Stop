import java.util.HashMap;

public class Player {
	private int NumPlayers=0;
	private String Difficulty="";
	private static Player player_instance = null;
	private int Claims=0;
	private int playerID;
	private WindowDemo windowDemo;
	public Player() {
		
	}
	
	public static Player PlayerSingleton()
    {
        // To ensure only one instance is created
        if (player_instance == null) {
        	player_instance = new Player();
        }
        return player_instance;
    }
	public int getNumPlayers() {
		return NumPlayers;
	}

	public void setNumPlayers(int numPlayers) {
		NumPlayers = numPlayers;
	}

	public String getDifficulty() {
		return Difficulty;
	}

	public void setDifficulty(String difficulty) {
		Difficulty = difficulty;
	}
	public int getPlayerID() {
		return playerID;
	}
	public void setPlayerID(int playerID) {
		this.playerID = playerID;
	}

	public WindowDemo getWindowDemo() {
		return windowDemo;
	}

	public void setWindowDemo(WindowDemo windowDemo) {
		this.windowDemo = windowDemo;
	}

}
